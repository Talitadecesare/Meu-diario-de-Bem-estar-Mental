import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';

export default function Formulario({ onSave, onCancel, registroEmEdicao }) {
  const [horasAutocuidado, setHorasAutocuidado] = useState('');
  const [momentosGratidao, setMomentosGratidao] = useState('');
  const [interacoesSociais, setInteracoesSociais] = useState('');

  useEffect(() => {
    if (registroEmEdicao) {
      setHorasAutocuidado(String(registroEmEdicao.autocuidado || ''));
      setMomentosGratidao(String(registroEmEdicao.gratidao || ''));
      setInteracoesSociais(String(registroEmEdicao.interacoes || ''));
    } else {
      setHorasAutocuidado('');
      setMomentosGratidao('');
      setInteracoesSociais('');
    }
  }, [registroEmEdicao]);

  const handleSaveClick = () => {
    if (!horasAutocuidado || !momentosGratidao || !interacoesSociais) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos antes de salvar!');
      return;
    }

    onSave(horasAutocuidado, momentosGratidao, interacoesSociais);
  };

  return (
    <View style={styles.card}>
      <Text style={styles.subtitulo}>
        {registroEmEdicao ? 'Editando Registro (Atualização)' : 'Novo Registro (Criação)'}
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Horas dedicadas ao autocuidado"
        keyboardType="numeric"
        value={horasAutocuidado}
        onChangeText={setHorasAutocuidado}
      />

      <TextInput
        style={styles.input}
        placeholder="Quantos momentos de gratidão você teve?"
        keyboardType="numeric"
        value={momentosGratidao}
        onChangeText={setMomentosGratidao}
      />

      <TextInput
        style={styles.input}
        placeholder="Quantas interações sociais você teve?"
        keyboardType="numeric"
        value={interacoesSociais}
        onChangeText={setInteracoesSociais}
      />

      <TouchableOpacity style={styles.botao} onPress={handleSaveClick}>
        <Text style={styles.botaoTexto}>
          {registroEmEdicao ? 'Atualizar Registro' : 'Gravar no Arquivo'}
        </Text>
      </TouchableOpacity>

      {registroEmEdicao && (
        <TouchableOpacity style={styles.botaoCancelar} onPress={onCancel}>
          <Text style={styles.botaoTexto}>Cancelar Edicao</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 15,
    marginHorizontal: 15,
    marginBottom: 20,
    elevation: 3,
  },
  subtitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#34495e',
  },
  input: {
    borderWidth: 1,
    borderColor: '#cccccc',
    borderRadius: 5,
    padding: 12,
    fontSize: 16,
    marginBottom: 10,
  },
  botao: {
    backgroundColor: '#3498db',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 5,
  },
  botaoTexto: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  botaoCancelar: {
    backgroundColor: '#7f8c8d',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 10,
  },
});
